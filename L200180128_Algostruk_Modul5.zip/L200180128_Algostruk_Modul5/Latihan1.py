def swap(A, p , q):
    tmp = A[p]
    A[p] = A[q]
    A[q] = tmp
